package oldPuzzle;

public enum Orientation {
	UP, DOWN, LEFT, RIGHT
}
