package n_i_u;

public class TryBig {
	float diffMatrix[][][]=new float[10000][10000][4];
	
	public TryBig() {
//		diffMatrix=new float[10000][40000];
//		for(int k=0;k<100000;k++){
//			for(int i=0;i<1000;i++){
//				for(int j=0;j<1000;j++){
//					diffMatrix[i][j]=i;
//				}
//			}
//		}
	}
	
	public static void main(String[] args) {
		new TryBig();
	}
}
